import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { db } from "../../firebase";
import {
  doc,
  onSnapshot,
  collection,
  query,
  where,
  Timestamp,
} from "firebase/firestore";
import Menu from "../menu/Menu";
import arrow from "../shop-view-seller/pics/arrow.png";
import { AllReviews } from "./AllReviews";
import { MarketInsights } from "./MarketInsights";
import Footer from "../footer/Foooter";
import { AnimatedSection } from "../animation/AnimatedSection";
import "./ItemStat.css";

export const ItemStat = () => {
  const { itemId } = useParams();
  const [period, setPeriod] = useState("1 month");
  const [chartData, setChartData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [itemData, setItemData] = useState(null);
  const [reviewStats, setReviewStats] = useState({
    averageRating: 0,
    totalReviews: 0,
  });
  const [allReviews, setAllReviews] = useState([]);

  const handlePeriodChange = (e) => setPeriod(e.target.value);

  // Fetch product and reviews
  useEffect(() => {
    const unsubProduct = onSnapshot(doc(db, "products", itemId), (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        setItemData({
          ...data,
          image: data.photos?.[0] || "",
          totalOrders: data.totalOrders || 0,
          favorites: data.favorites || 0,
          restockLevel: 30,
        });
      } else {
        console.warn("Item not found");
      }
      setLoading(false);
    });

    const reviewsQuery = query(
      collection(db, "reviews"),
      where("itemId", "==", itemId)
    );

    const unsubscribeReviews = onSnapshot(reviewsQuery, (querySnapshot) => {
      const reviews = [];
      let ratingSum = 0;

      querySnapshot.forEach((doc) => {
        const data = doc.data();
        reviews.push(data);
        ratingSum += data.rating;
      });

      setReviewStats({
        averageRating:
          reviews.length > 0 ? (ratingSum / reviews.length).toFixed(1) : 0,
        totalReviews: reviews.length,
      });

      setAllReviews(reviews);
    });

    return () => {
      unsubProduct();
      unsubscribeReviews();
    };
  }, [itemId]);

  // Fetch order chart data
  useEffect(() => {
    const fetchChartData = async () => {
      const now = new Date();
      const startDate = new Date();

      if (period === "1 month") startDate.setMonth(now.getMonth() - 1);
      else if (period === "3 months") startDate.setMonth(now.getMonth() - 3);
      else if (period === "6 months") startDate.setMonth(now.getMonth() - 6);
      else if (period === "1 year") startDate.setFullYear(now.getFullYear() - 1);

      const q = query(
        collection(db, "orders"),
        where("createdAt", ">=", Timestamp.fromDate(startDate))
      );

      const unsubscribe = onSnapshot(q, (querySnapshot) => {
        const rawData = {};

        querySnapshot.forEach((doc) => {
          const data = doc.data();
          const orderDate = data.createdAt.toDate();

          data.items?.forEach((item) => {
            if (item.id === itemId) {
              let key = "";

              if (period === "1 month") {
                key = `Week ${Math.ceil(orderDate.getDate() / 7)}`;
              } else {
                key = orderDate.toLocaleString("default", { month: "short" });
              }

              rawData[key] = (rawData[key] || 0) + 1;
            }
          });
        });

        const chartArr = Object.entries(rawData).map(([name, orders]) => ({
          name,
          orders,
        }));

        // Optional: sort by time period
        if (period !== "1 month") {
          const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
          chartArr.sort((a, b) => months.indexOf(a.name) - months.indexOf(b.name));
        }

        setChartData(chartArr);
      });

      return () => unsubscribe();
    };

    fetchChartData();
  }, [itemId, period]);

  if (loading) return <p>Loading item statistics...</p>;
  if (!itemData) return <p>Item not found.</p>;

  const { title, image, totalOrders, quantity, restockLevel, favorites } = itemData;

  return (
    <div className="item-stat-page">
      <Menu />
      <AnimatedSection>
        <div className="edit-section-title">
          <Link to="/your-shop" className="go-back">
            <img src={arrow} alt="arrow" className="arrow" />
          </Link>
          <p className="edit-featured-title">Item Statistics</p>
        </div>
      </AnimatedSection>

      <div className="item-stat-section">
        <AnimatedSection>
          <div className="item-stat-section-info">
            <div className="item-stat-section-info-img">
              <p className="item-stat-section-info-dess-title-1">Image Preview</p>
              <img src={image} alt="Item" />
            </div>
            <div className="item-stat-section-info-desc">
              <div className="item-stat-section-info-desc-title">
                <p className="item-stat-section-info-dess-title-1">Item Name</p>
                <p className="item-stat-section-info-desc-title-item">{title}</p>
              </div>
              <div className="item-stat-section-info-desc-rating">
                <p>Average Rate: {reviewStats.averageRating}/5</p>
                <div className="stars-2">
                  {"★".repeat(Math.floor(reviewStats.averageRating))}
                  {reviewStats.averageRating % 1 >= 0.5 ? "½" : ""}
                </div>
              </div>
            </div>
          </div>
        </AnimatedSection>

        <AnimatedSection>
          <div className="stats-graph">
            <div className="stats-graph-1">
              {[
                { label: "Total Orders", value: totalOrders },
                { label: "Total Reviews", value: reviewStats.totalReviews },
                { label: "Favorited", value: favorites },
              ].map((stat, index) => (
                <div key={index} className="stats-graph-1-item">
                  <div className="green-square"></div>
                  <div className="stats-graph-1-item-info">
                    <p className="stats-graph-1-item-info-title">{stat.label}:</p>
                    <p className="stats-graph-1-item-info-desc">{stat.value}</p>
                  </div>
                  {index < 2 && <div className="line-4"></div>}
                </div>
              ))}
            </div>
          </div>
        </AnimatedSection>

        <AnimatedSection>
          <div className="chart-container">
            <div className="time-period-selector">
              <label htmlFor="timePeriod">Total Items Purchased Over </label>
              <select id="timePeriod" value={period} onChange={handlePeriodChange}>
                <option value="1 month">1 Month</option>
                <option value="3 months">3 Months</option>
                <option value="6 months">6 Months</option>
                <option value="1 year">1 Year</option>
              </select>
            </div>

            <ResponsiveContainer width="100%" height={400}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="orders" fill="#2A4C4C" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </AnimatedSection>

        <AnimatedSection>
          <div className="inventory-section">
            <h3 className="reviews-title">Inventory & Supply Chain</h3>
            <div className="inventory-details">
              <p>
                <strong>Current Stock:</strong> {quantity} units available
              </p>
              <p>
                <strong>Restock Level:</strong> {restockLevel} units (Expected restock in 2 weeks)
              </p>
              {quantity < restockLevel / 2 && (
                <p style={{ color: "red", fontWeight: "bold" }}>
                  It’s better to restock now, as stock levels are low!
                </p>
              )}
            </div>
          </div>
        </AnimatedSection>

        <AnimatedSection>
          <AllReviews itemId={itemId} />
        </AnimatedSection>

        <AnimatedSection>
          <MarketInsights itemId={itemId} />
        </AnimatedSection>
      </div>

      <AnimatedSection>
        <Footer />
      </AnimatedSection>
    </div>
  );
};
