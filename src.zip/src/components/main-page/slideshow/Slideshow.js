import Carousel from "./Carousel"
import './Slideshow.css'
const Slideshow = () =>{
    return(
        <div className="carousel-main">
            <Carousel/>
        </div>
    )
}
export default Slideshow